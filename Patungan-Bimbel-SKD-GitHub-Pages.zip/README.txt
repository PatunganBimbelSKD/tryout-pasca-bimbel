PATUNGAN BIMBEL SKD — TRYOUT TIU PASCA-BIMBEL
================================================

ISI WEBSITE
- index.html: website utama
- questions-data.js: data soal, opsi, kunci, dan pembahasan
- assets/: logo transparan, ikon aplikasi, dan gambar asli yang diperlukan
- manifest.webmanifest: metadata PWA
- sw.js: service worker untuk cache/offline

LOGIN DEMO
- Username: patungankokel
- Password: 12345

PASANG DI GITHUB PAGES (CARA MUDAH DARI HP)
1. Buat repository baru di GitHub.
2. Upload file ZIP ini ke root repository.
3. Buat file baru dengan nama .github/workflows/deploy.yml.
4. Isi workflow tersebut dengan konfigurasi GitHub Pages yang diberikan bersama panduan instalasi.
5. Pada Settings > Pages, pilih Source: GitHub Actions.
6. Buka tab Actions dan tunggu workflow selesai. URL website akan muncul pada hasil deployment.

PASANG LANGSUNG (LEBIH MUDAH DARI KOMPUTER)
1. Ekstrak ZIP ini.
2. Upload seluruh ISI folder ke root repository, bukan ZIP-nya.
3. Pastikan index.html berada di root repository.
4. Buka Settings > Pages.
5. Pilih Deploy from a branch, branch main, folder /(root), lalu Save.

FITUR
- 35 soal TIU dengan pilihan A-E
- Timer 40 menit
- Navigasi soal dan penanda ragu-ragu
- Simpan progres lokal di browser
- Statistik nilai setelah pengumpulan
- Pembahasan setelah ujian
- Tampilan responsif desktop dan mobile

CATATAN PENTING
- Website ini merupakan simulasi latihan, bukan aplikasi resmi BKN.
- Login demo dan kunci jawaban tersimpan di sisi browser; ini bukan autentikasi aman untuk ujian publik. Jangan gunakan password pribadi atau rahasia.
- Jawaban peserta tersimpan di browser/perangkat yang dipakai, bukan database server.
- Untuk banyak peserta dengan hasil terpusat dan kunci jawaban terlindungi, diperlukan backend/authentication seperti Supabase.
