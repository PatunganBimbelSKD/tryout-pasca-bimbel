PATUNGAN BIMBEL SKD — TRYOUT TIU PASCA-BIMBEL @KOKEL_
=====================================================
RELEASE: CAT DESIGN V3.4 — CERTIFICATE FEATURE

ARAH DESAIN
- Antarmuka CAT yang bersih, tegas, profesional, dan mudah dipakai.
- Identitas navy, putih, dan aksen emas/teal.
- Login, dashboard awal, ruang ujian, hasil, pembahasan, dan sertifikat memakai satu sistem visual.
- Layout responsif untuk desktop, tablet, dan ponsel.
- Pilihan teks menggunakan kartu vertikal selebar area jawaban.
- Pilihan visual A-E menggunakan lima tombol seragam.
- Logo V3.3 menggunakan SVG inline di index.html (bukan PNG/JPG/WebP); ilustrasi toga, tiga figur peserta didik, buku terbuka, dan tassel tetap dipertahankan.

MATERI SUMBER
- Soal: Soal Tryout Bimbel KOKEL.pdf
- Pembahasan: Pembahasan Kokel (1).pdf
- questions-data.js dipertahankan byte-for-byte dari paket V3.3.
- SHA-256 questions-data.js: d743e000fc62a8cf80f0895e180c899088bcdf19dcc895380c9b09466c42405a
- Diagram soal dan pembahasan memakai aset gambar yang ada di paket sumber.

FITUR
- 35 soal TIU, pilihan A-E, kunci, dan pembahasan.
- Timer 40 menit, progres, navigasi nomor 1-35.
- Status dijawab, belum dijawab, dan ragu-ragu.
- Simpan jawaban lokal otomatis.
- Konfirmasi pengumpulan dan auto-submit saat waktu habis.
- Rekap nilai, jumlah benar/salah/kosong, dan akurasi.
- Pembahasan per soal, filter, pembesaran diagram, dan cetak hasil.
- Sertifikat penyelesaian tersedia setelah tryout dikumpulkan.
- Nama peserta dimasukkan sebelum sertifikat dibuat.
- Sertifikat mencantumkan judul tryout, nilai /175, jawaban benar /35, akurasi, tanggal, waktu pengerjaan, dan nomor sertifikat unik.
- Tombol Cetak / Simpan PDF memakai dialog cetak browser; pilih "Save as PDF" untuk menyimpan PDF.
- Sertifikat merupakan bukti penyelesaian simulasi Patungan Bimbel SKD, bukan sertifikat resmi BKN atau bukti kelulusan seleksi.

LOGIN DEMO
- Username: patungankokel
- Password: 12345

CATATAN
- Ini simulasi latihan mandiri, bukan aplikasi resmi BKN.
- Judul tryout: Tryout TIU Pasca-Bimbel @Kokel_.
- Login demo dan kunci jawaban berada di sisi browser.
- Jawaban dan nama sertifikat tersimpan pada browser/perangkat, bukan server terpusat.

GITHUB PAGES — ALUR REPOSITORY DENGAN GITHUB ACTIONS
- Nama arsip yang dipakai workflow saat ini: Patungan-Bimbel-SKD-GitHub-Pages.zip.
- Letakkan ZIP tersebut di root repository GitHub (sejajar dengan folder .github).
- Workflow deploy.yml akan mengekstrak ZIP ke folder site, lalu menerbitkannya ke GitHub Pages.
- Karena workflow sudah mengekstrak arsip, untuk pembaruan cukup ganti ZIP lama dengan ZIP V3.4 bernama sama; tidak perlu mengunggah folder hasil ekstraksi satu per satu.
- Pastikan index.html berada di root ZIP, bukan di dalam folder bertingkat.
- Setelah commit, buka tab Actions dan pastikan job build serta deploy berstatus hijau.
- Service worker cache v16 akan meminta browser mengambil versi terbaru setelah deployment. Jika tampilan lama masih muncul, tutup tab website lalu buka kembali atau hapus data situs/cache untuk domain GitHub Pages.
