const CACHE_NAME = "patungan-skd-cat-v16";
const CORE_ASSETS = [
  "./",
  "./index.html",
  "./questions-data.js",
  "./manifest.webmanifest",
  "./assets/favicon.svg",
  "./assets/brand-mark.svg",
  "./assets/brand-lockup-dark.svg",
  "./assets/brand-lockup-white.svg",
  "./assets/patungan-app-icon.svg",
  "./assets/figures/q28.webp",
  "./assets/figures/q29.webp",
  "./assets/figures/q30.webp",
  "./assets/figures/q31.webp",
  "./assets/figures/q32.webp",
  "./assets/figures/q33.webp",
  "./assets/figures/q34.webp",
  "./assets/figures/q35.webp",
  "./assets/figures/explanation-q09.webp"
];

self.addEventListener("install", event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(CORE_ASSETS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", event => {
  if (event.request.method !== "GET") return;
  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        if (response && response.ok) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
        }
        return response;
      }).catch(() => caches.match("./index.html"));
    })
  );
});
