/* Transkripsi materi dari PDF soal dan PDF pembahasan yang diberikan pengguna.
   Diagram/pola gambar memakai potongan gambar asli dari PDF sumber. */
window.TRYOUT_QUESTIONS = [
  {
    prompt: "PESTISIDA : HAMA = ..... : .....",
    options: ["Vaksin - Penyakit", "Pupuk - Tanaman", "Sabun - Air", "Antibiotik - Bakteri", "Obat - Dokter"],
    answer: "D",
    explanation: [
      "Pola: zat pembasmi : yang dibasmi.",
      "Pestisida dipakai untuk membasmi hama, sebagaimana antibiotik dipakai untuk membasmi bakteri.",
      "Hati-hati: vaksin berfungsi MENCEGAH penyakit, bukan membasmi.",
      "Jawaban: D"
    ]
  },
  {
    prompt: "Pemilik sebuah kafe di Kota Prima mengklaim bahwa pemasangan Wi-Fi gratis telah meningkatkan omzet harian kafenya. Klaim ini didasarkan pada data bahwa omzet rata-rata harian naik 30% dalam dua bulan setelah Wi-Fi dipasang. Manakah pernyataan berikut yang paling MEMPERLEMAH klaim pemilik kafe tersebut?",
    options: [
      "Sebagian besar pelanggan kafe tersebut adalah mahasiswa",
      "Harga paket internet rumahan di Kota Prima naik dalam dua bulan terakhir",
      "Data kasir menunjukkan kenaikan omzet berasal dari pesanan katering kantor yang mulai diterima pada bulan yang sama.",
      "Kafe lain di luar Kota Prima juga memasang Wi-Fi gratis",
      "Pelanggan mengaku lebih betah duduk berlama-lama sejak ada Wi-Fi"
    ],
    answer: "C",
    explanation: [
      "Inti cerita: Wi-Fi gratis dipasang → omzet naik 30%. Pemilik menganggap Wi-Fi penyebabnya.",
      "Opsi C menunjukkan PENYEBAB LAIN: kenaikan omzet datang dari pesanan katering kantor, sedangkan penjualan di tempat (yang seharusnya terpengaruh Wi-Fi) tidak berubah. Jadi kenaikan omzet bukan karena Wi-Fi.",
      "Jawaban: C"
    ]
  },
  {
    prompt: "Kepala Dinas Perhubungan Kota Arga menyatakan bahwa pemasangan kamera tilang elektronik di 10 persimpangan telah menurunkan angka kecelakaan. Pernyataan ini didasarkan pada data bahwa angka kecelakaan di 10 persimpangan tersebut turun 35% dalam satu tahun setelah kamera dipasang. Manakah pernyataan berikut yang paling MEMPERKUAT pernyataan Kepala Dinas Perhubungan tersebut?",
    options: [
      "Di 10 persimpangan lain dengan kepadatan lalu lintas serupa yang tidak dipasang kamera, angka kecelakaan pada periode yang sama hanya turun 3%",
      "Jumlah pelanggaran yang terekam kamera mencapai ribuan kasus setiap bulan",
      "Survei menunjukkan sebagian besar warga Kota Arga mendukung program tilang elektronik",
      "Pada periode yang sama, marka jalan dan lampu lalu lintas di 10 persimpangan tersebut juga diperbaiki",
      "Angka kecelakaan secara nasional turun 30% pada tahun yang sama"
    ],
    answer: "A",
    explanation: [
      "Inti cerita: Kamera tilang dipasang — kecelakaan di 10 persimpangan turun 35%.",
      "Opsi A memberi PEMBANDING yang adil: persimpangan dengan kepadatan serupa tanpa kamera hanya turun 3%. Artinya penurunan besar (35%) memang terjadi di persimpangan yang dipasang kamera, sehingga klaim makin kuat.",
      "Jawaban: A"
    ]
  },
  {
    prompt: "Dinas Pendidikan Kabupaten Sarwa menyimpulkan bahwa program bimbingan belajar gratis efektif meningkatkan nilai ujian siswa. Kesimpulan ini didasarkan pada data bahwa rata-rata nilai ujian 200 siswa peserta program naik 15 poin dibandingkan nilai ujian mereka pada tahun lalu. Manakah pernyataan berikut yang paling MEMPERLEMAH kesimpulan Dinas Pendidikan tersebut?",
    options: [
      "Sebagian besar peserta program bimbingan belajar berasal dari keluarga dengan penghasilan menengah ke bawah",
      "Siswa yang tidak mengikuti program bimbingan belajar juga mengalami kenaikan nilai ujian rata-rata sebesar 2 poin",
      "Kenaikan nilai ujian tahun ini terjadi karena soal ujian disusun lebih mudah dibandingkan soal tahun lalu",
      "Peserta program bimbingan belajar dipilih melalui seleksi dan sebelumnya sudah memiliki nilai di atas rata-rata",
      "Peserta program bimbingan belajar mengaku lebih percaya diri menghadapi ujian setelah mengikuti program tersebut"
    ],
    answer: "C",
    explanation: [
      "Inti cerita: Program bimbingan belajar diikuti — nilai ujian peserta naik 15 poin. Dinas menganggap program bimbel sebagai penyebab kenaikan.",
      "Opsi C menunjukkan PENYEBAB LAIN: soal ujian tahun ini lebih mudah, sehingga kenaikan nilai bisa terjadi tanpa program bimbel. Jadi kenaikan 15 poin belum tentu karena program.",
      "Jawaban: C"
    ]
  },
  {
    prompt: "Semua kurir ekspres menggunakan aplikasi pelacak. Tidak ada pengguna aplikasi pelacak yang bekerja tanpa asuransi. Tidak semua pengguna aplikasi pelacak bekerja di bidang logistik. Kesimpulan ...",
    options: [
      "Sebagian kurir ekspres bekerja tanpa asuransi.",
      "Semua pengguna aplikasi pelacak adalah kurir ekspres.",
      "Tidak ada kurir ekspres yang bekerja tanpa asuransi.",
      "Sebagian kurir ekspres tidak menggunakan aplikasi pelacak.",
      "Semua pekerja tanpa asuransi adalah kurir ekspres."
    ],
    answer: "C",
    explanation: [
      "Berdasarkan Premis 1, seluruh kurir ekspres dipastikan menggunakan aplikasi pelacak.",
      "Dari Premis 2, tidak ada satu pun pengguna aplikasi pelacak yang bekerja tanpa asuransi.",
      "Karena kurir ekspres termasuk pengguna aplikasi pelacak, maka tidak ada kurir ekspres yang bekerja tanpa asuransi.",
      "Premis 3 hanya pengecoh (tidak menentukan hubungan kurir dan asuransi).",
      "Jawaban: C"
    ]
  },
  {
    prompt: "Jika kuota formasi bertambah, maka jumlah peserta yang lolos SKD meningkat. Jumlah peserta yang lolos SKD meningkat. Kesimpulan yang paling tepat adalah ...",
    options: [
      "Kuota formasi bertambah",
      "Kuota formasi tidak bertambah",
      "Jumlah peserta yang lolos SKD tidak meningkat",
      "Kuota formasi mungkin bertambah",
      "Tidak dapat disimpulkan"
    ],
    answer: "D",
    explanation: [
      "Bentuk premis: P → Q, lalu Q terjadi.",
      "Ini modus ponens yang dibalik, sehingga P TIDAK PASTI terjadi (bisa saja peserta lolos meningkat karena hal lain).",
      "Biasanya jawabannya ‘Tidak dapat disimpulkan’. TETAPI karena di opsi ada kata ‘mungkin’, jawaban yang tepat adalah ‘Kuota formasi mungkin bertambah’ (opsi D).",
      "Ingat klausul TDDS: TDDS tidak berlaku kalau di opsi ada kata ‘mungkin’."
    ]
  },
  {
    prompt: "Jika seorang peserta lulus SKD dan lulus SKB, maka ia diangkat menjadi CPNS. Jika peserta diangkat menjadi CPNS, maka ia mengikuti latsar. Dodi tidak mengikuti latsar. Kesimpulan yang pasti benar adalah ...",
    options: [
      "Dodi tidak lulus SKD dan tidak lulus SKB",
      "Dodi tidak lulus SKD atau tidak lulus SKB",
      "Dodi lulus SKD tetapi tidak lulus SKB",
      "Dodi diangkat menjadi CPNS",
      "Tidak dapat disimpulkan"
    ],
    answer: "B",
    explanation: [
      "Gabungkan premis 1 dan 2: Jika seseorang lulus SKD dan SKB, maka ia akan mengikuti latsar.",
      "Premis 3: Dodi tidak mengikuti latsar.",
      "Artinya Dodi tidak — ingkaran dari ‘lulus SKD dan lulus SKB’.",
      "Ingkaran ‘P dan Q’ adalah ‘tidak P atau tidak Q’.",
      "Sehingga: Dodi tidak lulus SKD atau tidak lulus SKB (opsi B).",
      "Jawaban: B"
    ]
  },
  {
    prompt: "Enam orang (Ayu, Bayu, Citra, Deni, Eko, dan Fira) antre di depan loket, dengan ketentuan:",
    bullets: [
      "Eko berada di urutan keempat dari depan.",
      "Citra berada tepat di belakang Ayu.",
      "Bayu berada di belakang Citra dengan tepat dua orang di antara mereka.",
      "Deni berada di depan Ayu.",
      "Fira tidak berada di urutan paling depan."
    ],
    after: "Orang yang berada di urutan kelima dari depan adalah ...",
    options: ["Ayu", "Bayu", "Citra", "Deni", "Fira"],
    answer: "E",
    explanation: [
      "Hasil analisa ketentuan urutan dari soal adalah:",
      "Urutan dari depan: Deni - Ayu - Citra - Eko - Fira - Bayu.",
      "Urutan kelima adalah Fira.",
      "Jawaban: E"
    ]
  },
  {
    prompt: "Delapan orang (Galih, Hesti, Ilham, Jihan, Kevin, Lala, Mira, dan Nanda) duduk mengelilingi meja bundar dengan 8 kursi berjarak sama dan semuanya menghadap ke meja, dengan ketentuan:",
    bullets: [
      "Kevin duduk berhadapan dengan Galih.",
      "Hesti duduk tepat di sebelah kiri Galih.",
      "Mira duduk berhadapan dengan Hesti.",
      "Jihan duduk bersebelahan dengan Kevin.",
      "Nanda duduk bersebelahan dengan Galih.",
      "Ilham tidak duduk bersebelahan dengan Hesti maupun Kevin."
    ],
    after: "Siapakah yang duduk tepat di sebelah kanan Lala?",
    options: ["Galih", "Hesti", "Jihan", "Mira", "Nanda"],
    answer: "B",
    explanationFigure: "explanation-q09.webp",
    explanationFigureAfter: 6,
    explanation: [
      "Hasil analisa dari ketentuan soal:",
      "1) Galih di atas, Kevin di bawah (berhadapan).",
      "2) Hesti tepat di kiri Galih dan Mira berhadapan dengan Hesti.",
      "3) Nanda bersebelahan dengan Galih — kursi kiri atas (kanan atas sudah Hesti).",
      "4) Jihan bersebelahan dengan Kevin → kursi kanan bawah (kiri bawah sudah Mira).",
      "5) Sisa kursi: kanan (antara Hesti dan Jihan) dan kiri (antara Mira dan Nanda). Ilham tidak boleh bersebelahan dengan Hesti → Ilham di kursi kiri, Lala di kursi kanan.",
      "Lala menghadap ke kiri (ke meja), sehingga sebelah kanannya adalah kursi kanan atas, yaitu Hesti.",
      "Jawaban: B"
    ]
  },
  {
    prompt: "Lima penampil, yaitu Rara, Sena, Tiar, Umi, dan Vino, tampil secara berurutan sesuai urutan nama tersebut. Setiap penampil mendapat salah satu dari tiga nilai, yaitu A, B, atau C. Diketahui bahwa:",
    bullets: [
      "(1) Penampil pertama dan penampil kelima mendapat nilai yang sama.",
      "(2) Tidak ada dua penampil berurutan yang sama-sama mendapat nilai C."
    ],
    after: "Manakah susunan nilai yang memenuhi seluruh ketentuan tersebut?",
    options: [
      "Rara (B), Sena (C), Tiar (C), Umi (A), Vino (B)",
      "Rara (C), Sena (A), Tiar (B), Umi (A), Vino (B)",
      "Rara (A), Sena (C), Tiar (B), Umi (C), Vino (A)",
      "Rara (A), Sena (B), Tiar (C), Umi (C), Vino (A)",
      "Rara (B), Sena (A), Tiar (C), Umi (B), Vino (C)"
    ],
    answer: "C",
    explanation: [
      "Diketahui,",
      "Ketentuan (1): nilai Rara = nilai Vino. Cukup bandingkan penampil pertama dan terakhir.",
      "Ketentuan (2): tidak boleh ada nilai C yang berdampingan.",
      "Periksa setiap opsi berdasarkan ketentuan:",
      "A. Rara (B) - Vino (B), tetapi Sena (C) dan Tiar (C) berdampingan — Tidak memenuhi.",
      "B. Rara (C) ≠ Vino (B) — Tidak memenuhi.",
      "C. Rara (A) = Vino (A), nilai C (Sena dan Umi) tidak berdampingan — Memenuhi seluruh ketentuan.",
      "D. Rara (A) = Vino (A), tetapi Tiar (C) dan Umi (C) berdampingan — Tidak memenuhi.",
      "E. Rara (B) ≠ Vino (C) — Tidak memenuhi.",
      "Sehingga yang memenuhi seluruh ketentuan adalah opsi C.",
      "Jawaban: C"
    ]
  },
  {
    prompt: "Seorang pustakawan akan menyusun 8 buku, yaitu 2 buku Matematika, 2 buku Fisika, 2 buku Kimia, 1 buku Biologi, dan 1 buku Sejarah, ke dalam tiga rak, yaitu rak atas, rak tengah, dan rak bawah. Diketahui bahwa:",
    bullets: [
      "(1) Rak atas memuat maksimal 2 buku, rak tengah dan rak bawah masing-masing maksimal 3 buku.",
      "(2) Kedua buku Fisika harus berada di rak yang sama.",
      "(3) Buku Kimia tidak boleh berada di rak yang sama dengan buku Biologi."
    ],
    after: "Manakah susunan buku yang memenuhi seluruh ketentuan tersebut?",
    options: [
      "Atas: Fisika, Fisika, Sejarah; Tengah: Matematika, Kimia, Kimia; Bawah: Matematika, Biologi",
      "Atas: Matematika, Fisika; Tengah: Fisika, Kimia, Kimia; Bawah: Matematika, Biologi, Sejarah",
      "Atas: Matematika, Sejarah; Tengah: Fisika, Fisika, Kimia; Bawah: Matematika, Kimia, Biologi",
      "Atas: Fisika, Fisika; Tengah: Matematika, Kimia, Kimia; Bawah: Matematika, Biologi, Sejarah",
      "Atas: Fisika, Fisika; Tengah: Matematika, Kimia, Biologi; Bawah: Matematika, Kimia, Sejarah"
    ],
    answer: "D",
    explanation: [
      "Diketahui, ketentuan (1): atas maks 2, tengah maks 3, bawah maks 3 buku.",
      "Ketentuan (2): dua buku Fisika harus satu rak.",
      "Ketentuan (3): Kimia dan Biologi tidak boleh satu rak.",
      "Periksa setiap opsi berdasarkan ketentuan:",
      "A. Rak atas berisi 3 buku → Tidak memenuhi.",
      "B. Fisika terpisah di rak atas dan tengah — Tidak memenuhi.",
      "C. Rak bawah berisi Kimia dan Biologi → Tidak memenuhi.",
      "D. Atas 2 buku, tengah 3, bawah 3; Fisika satu rak; Biologi tidak bersama Kimia → Memenuhi seluruh ketentuan.",
      "E. Rak tengah berisi Kimia dan Biologi — Tidak memenuhi.",
      "Sehingga yang memenuhi seluruh ketentuan adalah opsi D.",
      "Jawaban: D"
    ]
  },
  {
    prompt: "Nilai yang paling mendekati hasil operasi berikut adalah ...",
    formula: { type: "fraction", numerator: "49,6 × 6,02", denominator: "2,48" },
    options: ["100", "110", "120", "130", "140"],
    answer: "C",
    explanation: [
      "Bulatkan ke angka mudah:",
      "49,6 ≈ 50",
      "6,02 ≈ 6",
      "2,48 ≈ 2,5",
      "(50 × 6) ÷ 2,5 = 300 ÷ 2,5 = 120.",
      "Jawaban: C. 120"
    ]
  },
  {
    prompt: "Nilai yang paling mendekati hasil operasi berikut adalah ...",
    formula: { type: "math", text: "(0,1251 × 6.396) + (33,4% × 1.803)" },
    options: ["1.100", "1.200", "1.300", "1.400", "1.500"],
    answer: "D",
    explanation: [
      "Ubah ke pecahan istimewa:",
      "0,1251 ≈ 0,125 = 1/8",
      "33,4% ≈ 1/3",
      "6.396 ≈ 6.400",
      "1.803 ≈ 1.800",
      "(1/8 × 6.400) + (1/3 × 1.800)",
      "= 800 + 600",
      "= 1.400",
      "Jawaban: D. 1.400"
    ]
  },
  {
    prompt: "Petugas koperasi mencatat dua bentuk perkalian jumlah kemasan gula yang tersedia di gudang. Manakah pasangan perkalian yang nilainya sama?",
    options: [
      "125 × 56 sama dengan 140 × 52",
      "35 × 72 sama dengan 45 × 54",
      "250 × 36 sama dengan 375 × 26",
      "48 × 175 sama dengan 56 × 140",
      "75 × 64 sama dengan 96 × 50"
    ],
    answer: "E",
    explanation: [
      "A. (125 × 56 sama dengan 140 × 52): Salah (7.000 ≠ 7.280).",
      "B. (35 × 72 sama dengan 45 × 54): Salah (2.520 ≠ 2.430).",
      "C. (250 × 36 sama dengan 375 × 26): Salah (9.000 ≠ 9.750).",
      "D. (48 × 175 sama dengan 56 × 140): Salah (8.400 ≠ 7.840).",
      "E. (75 × 64 sama dengan 96 × 50): Benar (4.800 = 4.800).",
      "Ikuti proses dan trik eliminasi opsi di kelas bimbel ya.",
      "Jawaban yang tepat adalah Opsi E."
    ]
  },
  {
    prompt: "Sebuah percetakan membagi sejumlah lembar kertas ke dalam beberapa bundel secara merata. Kombinasi yang menghasilkan jumlah kertas per bundel yang sama adalah ...",
    options: [
      "1.462 ÷ 34 sama dengan 1.591 ÷ 37",
      "1.344 ÷ 32 sama dengan 1.395 ÷ 31",
      "1.625 ÷ 25 sama dengan 1.716 ÷ 26",
      "1.176 ÷ 24 sama dengan 1.250 ÷ 25",
      "1.596 ÷ 38 sama dengan 1.677 ÷ 39"
    ],
    answer: "A",
    explanation: [
      "A. (1.462 ÷ 34 sama dengan 1.591 ÷ 37): Benar (43 = 43).",
      "B. (1.344 ÷ 32 sama dengan 1.395 ÷ 31): Salah (42 ≠ 45).",
      "C. (1.625 ÷ 25 sama dengan 1.716 ÷ 26): Salah (65 ≠ 66).",
      "D. (1.176 ÷ 24 sama dengan 1.250 ÷ 25): Salah (49 ≠ 50).",
      "E. (1.596 ÷ 38 sama dengan 1.677 ÷ 39): Salah (42 ≠ 43).",
      "Ikuti proses dan trik eliminasi opsi di kelas bimbel ya.",
      "Jawaban yang tepat adalah Opsi A."
    ]
  },
  {
    prompt: "Diberikan matriks 3×3. Berdasarkan pola operasi pada baris, nilai X adalah ...",
    table: { headers: ["Kolom I", "Kolom II", "Kolom III"], rows: [["5", "7", "18"], ["6", "11", "25"], ["X", "4", "60"]] },
    options: ["5", "6", "7", "8", "9"],
    answer: "D",
    explanation: [
      "Cari pola dari baris yang lengkap:",
      "Pola: (Kolom I)² − Kolom II = Kolom III.",
      "Baris 1: 5² − 7 = 25 − 7 = 18.",
      "Baris 2: 6² − 11 = 36 − 11 = 25.",
      "Baris 3: X² − 4 = 60.",
      "X² = 64.",
      "X = 8.",
      "Jawaban: D. 8"
    ]
  },
  {
    prompt: "Diberikan matriks 3×4. Berdasarkan pola operasi pada baris, nilai X adalah ...",
    table: { headers: ["Kolom I", "Kolom II", "Kolom III", "Kolom IV"], rows: [["4", "5", "6", "19"], ["7", "X", "3", "13"], ["5", "9", "4", "11"]] },
    options: ["6", "7", "8", "9", "10"],
    answer: "C",
    explanation: [
      "Cari pola dari baris yang lengkap (baris 1 dan 3):",
      "Pola: (Kolom I × Kolom III) − Kolom II = Kolom IV.",
      "Baris 1: (4 × 6) − 5 = 24 − 5 = 19.",
      "Baris 3: (5 × 4) − 9 = 20 − 9 = 11.",
      "Baris 2: (7 × 3) − X = 13.",
      "21 − X = 13.",
      "X = 8.",
      "Jawaban: C. 8"
    ]
  },
  {
    prompt: "Perhatikan nomor suku dan nilainya pada tabel berikut. Berdasarkan pola deret, nilai T adalah ...",
    table: { headers: ["Nomor Suku", "Nilai Suku"], rows: [["2", "11"], ["5", "26"], ["9", "46"], ["15", "T"]] },
    options: ["71", "76", "81", "86", "91"],
    answer: "B",
    explanation: [
      "Rumus suku ke-n: Un = a + (n − 1)b.",
      "Cari b: (26 − 11) ÷ (5 − 2) = 15 ÷ 3 = 5.",
      "Cari a: U₂ = a + 5 = 11 → a = 6.",
      "Cek: U₉ = 6 + 8 × 5 = 46 (cocok).",
      "U₁₅ = 6 + 14 × 5 = 6 + 70 = 76.",
      "Cara rumus langsung: Un = 5n + 1 → U₁₅ = 75 + 1 = 76.",
      "Jawaban: B. 76"
    ]
  },
  {
    prompt: "Perhatikan nomor suku dan nilainya pada tabel berikut. Nomor suku yang tepat untuk mengisi titik-titik adalah ...",
    table: { headers: ["Nomor Suku", "Nilai Suku"], rows: [["3", "88"], ["7", "72"], ["10", "60"], [".....", "24"]] },
    options: ["19", "20", "21", "22", "23"],
    answer: "A",
    explanation: [
      "Rumus suku ke-n: Un = a + (n − 1)b.",
      "Cari b: (72 − 88) ÷ (7 − 3) = −16 ÷ 4 = −4 (deret turun).",
      "Cari a: U₃ = a + 2(−4) = 88 → a = 96.",
      "Cek: U₁₀ = 96 + 9(−4) = 60 (cocok).",
      "Yang ditanya nomor sukunya, nilainya 24:",
      "96 + (n − 1)(−4) = 24.",
      "(n − 1)(−4) = −72.",
      "n − 1 = 18.",
      "n = 19.",
      "Jawaban: A. 19"
    ]
  },
  {
    prompt: "Harga 2 kotak susu dan 3 bungkus roti adalah Rp95.000. Berapakah harga 1 kotak susu?",
    statements: [
      "PERNYATAAN (1): Harga 1 kotak susu Rp10.000 lebih mahal daripada harga 1 bungkus roti.",
      "PERNYATAAN (2): Harga 4 kotak susu dan 6 bungkus roti adalah Rp190.000."
    ],
    options: [
      "Pernyataan (1) SAJA cukup, tetapi (2) SAJA tidak cukup",
      "Pernyataan (2) SAJA cukup, tetapi (1) SAJA tidak cukup",
      "DUA pernyataan BERSAMA-SAMA cukup, tetapi SATU saja tidak",
      "Pernyataan (1) SAJA cukup dan pernyataan (2) SAJA cukup",
      "Pernyataan (1) dan (2) TIDAK CUKUP"
    ],
    answer: "A",
    explanation: [
      "Misalkan harga 1 kotak susu = s dan 1 bungkus roti = r. Diketahui 2s + 3r = 95.000.",
      "Uji Pernyataan (1): s = r + 10.000.",
      "2(r + 10.000) + 3r = 95.000.",
      "5r = 75.000 → r = 15.000 → s = 25.000.",
      "Pernyataan (1) SAJA CUKUP.",
      "Uji Pernyataan (2): 4s + 6r = 190.000 sama dengan 2 × (2s + 3r). Ini persamaan yang sama, bukan informasi baru.",
      "Pernyataan (2) SAJA TIDAK CUKUP.",
      "Kunci Jawaban: A"
    ]
  },
  {
    prompt: "Jika x dan y adalah bilangan real, berapakah nilai 2x + y?",
    statements: [
      "PERNYATAAN (1): 4x + 2y = 18.",
      "PERNYATAAN (2): x − y = 3."
    ],
    options: [
      "Pernyataan (1) SAJA cukup, tetapi (2) SAJA tidak cukup",
      "Pernyataan (2) SAJA cukup, tetapi (1) SAJA tidak cukup",
      "DUA pernyataan BERSAMA-SAMA cukup, tetapi SATU saja tidak",
      "Pernyataan (1) SAJA cukup dan pernyataan (2) SAJA cukup",
      "Pernyataan (1) dan (2) TIDAK CUKUP"
    ],
    answer: "A",
    explanation: [
      "Yang ditanya adalah nilai 2x + y, bukan nilai x dan y satu per satu.",
      "Uji Pernyataan (1): 4x + 2y = 18 → bagi 2 → 2x + y = 9.",
      "Nilai 2x + y pasti 9. Pernyataan (1) SAJA CUKUP.",
      "Uji Pernyataan (2): x − y = 3, hanya ada satu persamaan untuk dua variabel.",
      "Ingat pertanyaan soal berupa persamaan, tapi tidak bisa dipakai untuk eliminasi/substitusi.",
      "Pernyataan (2) SAJA TIDAK CUKUP.",
      "Kunci Jawaban: A"
    ]
  },
  {
    prompt: "Tabel berikut menunjukkan nilai tryout empat siswa.",
    table: { headers: ["Nama", "Nilai"], rows: [["Rina", "80"], ["Sandi", "x"], ["Tomi", "y"], ["Uli", "70"]] },
    after: "Apakah nilai Sandi lebih tinggi daripada nilai Rina?",
    statements: [
      "PERNYATAAN (1): Jumlah nilai Sandi dan Tomi adalah 150.",
      "PERNYATAAN (2): Nilai Tomi minimal 65."
    ],
    options: [
      "Pernyataan (1) SAJA cukup, tetapi (2) SAJA tidak cukup",
      "Pernyataan (2) SAJA cukup, tetapi (1) SAJA tidak cukup",
      "DUA pernyataan BERSAMA-SAMA cukup, tetapi SATU saja tidak",
      "Pernyataan (1) SAJA cukup dan pernyataan (2) SAJA cukup",
      "Pernyataan (1) dan (2) TIDAK CUKUP"
    ],
    answer: "E",
    explanation: [
      "Ditanyakan: apakah x > 80?",
      "Uji Pernyataan (1): x + y = 150. Bisa x = 90 (Ya) atau x = 70 (Tidak). Pernyataan (1) SAJA TIDAK CUKUP.",
      "Uji Pernyataan (2): y ≥ 65, tidak ada informasi tentang x. Pernyataan (2) SAJA TIDAK CUKUP.",
      "Uji DUA pernyataan BERSAMA-SAMA: x + y = 150 dan y ≥ 65, sehingga x ≤ 85.",
      "Jika y = 65 → x = 85 (lebih tinggi dari Rina). Jika y = 75 → x = 75 (lebih rendah dari Rina).",
      "Jawaban masih bisa ‘Ya’ atau ‘Tidak’. TIDAK CUKUP.",
      "Kunci Jawaban: E"
    ]
  },
  {
    prompt: "Sebuah proyek direncanakan selesai dalam 30 hari oleh sejumlah pekerja dengan kecepatan kerja yang sama. Berapa banyak pekerja tambahan yang diperlukan agar proyek selesai 6 hari lebih cepat dari rencana?",
    statements: [
      "PERNYATAAN (1): Jumlah pekerja awal adalah 24 orang.",
      "PERNYATAAN (2): Beban pekerjaan proyek setara dengan 720 orang-hari."
    ],
    options: [
      "Pernyataan (1) SAJA cukup, tetapi (2) SAJA tidak cukup",
      "Pernyataan (2) SAJA cukup, tetapi (1) SAJA tidak cukup",
      "DUA pernyataan BERSAMA-SAMA cukup, tetapi SATU saja tidak",
      "Pernyataan (1) SAJA cukup dan pernyataan (2) SAJA cukup",
      "Pernyataan (1) dan (2) TIDAK CUKUP"
    ],
    answer: "D",
    explanation: [
      "Beban kerja = jumlah pekerja × lama hari (tetap). Target baru = 30 − 6 = 24 hari.",
      "Uji Pernyataan (1): Beban = 24 × 30 = 720 orang-hari. Pekerja yang dibutuhkan = 720 ÷ 24 = 30 orang → tambahan 30 − 24 = 6 orang. Pernyataan (1) SAJA CUKUP.",
      "Uji Pernyataan (2): Pekerja awal = 720 ÷ 30 = 24 orang. Pekerja yang dibutuhkan = 720 ÷ 24 = 30 orang → tambahan 6 orang. Pernyataan (2) SAJA CUKUP.",
      "Kunci Jawaban: D"
    ]
  },
  {
    prompt: "Tabel berikut memuat hasil seleksi enam peserta.",
    table: { headers: ["Peserta", "Usia", "Nilai Tertulis", "Nilai Praktik"], rows: [["Anton", "31", "88", "72"], ["Bella", "27", "79", "81"], ["Candra", "29", "70", "90"], ["Dewi", "25", "85", "78"], ["Erik", "33", "66", "98"], ["Fani", "28", "82", "76"]] },
    paragraphs: [
      "Ketentuan:",
      "Peserta lulus jika nilai tertulis minimal 70 dan nilai praktik minimal 75.",
      "Peringkat ditentukan dari total kedua nilai. Jika total sama, peserta yang lebih TUA berada di peringkat lebih tinggi."
    ],
    after: "Tiga peserta dengan peringkat tertinggi, berurutan dari peringkat 1, adalah ...",
    options: ["Erik, Dewi, Candra", "Dewi, Bella, Candra", "Dewi, Candra, Bella", "Dewi, Candra, Fani", "Candra, Dewi, Bella"],
    answer: "C",
    explanation: [
      "Langkah 1: saring peserta yang lulus syarat.",
      "Anton: praktik 72 < 75 → tidak lulus.",
      "Erik: tertulis 66 < 70 → tidak lulus.",
      "Bella, Candra, Dewi, Fani → lulus.",
      "Langkah 2: hitung total.",
      "Dewi = 85 + 78 = 163.",
      "Bella = 79 + 81 = 160.",
      "Candra = 70 + 90 = 160.",
      "Fani = 82 + 76 = 158.",
      "Langkah 3: Bella dan Candra sama-sama 160 → yang lebih tua didahulukan: Candra (29 tahun) di atas Bella (27 tahun).",
      "Urutan: Dewi, Candra, Bella.",
      "Hati-hati: Erik punya total tertinggi (164), tetapi gugur di syarat nilai tertulis.",
      "Jawaban: C"
    ]
  },
  {
    prompt: "Data penjualan lima cabang toko dalam satu hari:",
    paragraphs: [
      "Cabang P: 10 transaksi, rata-rata belanja Rp100.000, biaya operasional Rp520.000.",
      "Cabang Q: 30 transaksi, rata-rata belanja Rp40.000, biaya operasional Rp800.000.",
      "Cabang R: 15 transaksi, rata-rata belanja Rp80.000, biaya operasional Rp700.000.",
      "Cabang S: 20 transaksi, rata-rata belanja Rp50.000, biaya operasional Rp450.000.",
      "Cabang T: 25 transaksi, rata-rata belanja Rp60.000, biaya operasional Rp1.050.000.",
      "Laba = jumlah transaksi × rata-rata belanja − biaya operasional. Cabang dengan laba terbesar adalah ..."
    ],
    options: ["Cabang P", "Cabang Q", "Cabang R", "Cabang S", "Cabang T"],
    answer: "D",
    explanation: [
      "Rumus: Laba = transaksi × rata-rata belanja − biaya operasional.",
      "Cabang P: 10 × 100.000 = 1.000.000 → laba = 1.000.000 − 520.000 = 480.000.",
      "Cabang Q: 30 × 40.000 = 1.200.000 → laba = 1.200.000 − 800.000 = 400.000.",
      "Cabang R: 15 × 80.000 = 1.200.000 → laba = 1.200.000 − 700.000 = 500.000.",
      "Cabang S: 20 × 50.000 = 1.000.000 → laba = 1.000.000 − 450.000 = 550.000.",
      "Cabang T: 25 × 60.000 = 1.500.000 → laba = 1.500.000 − 1.050.000 = 450.000.",
      "Sehingga, Cabang S memiliki laba terbesar, yaitu Rp550.000.",
      "Jawaban: D"
    ]
  },
  {
    prompt: "Panitia perkemahan akan menyewa tenda untuk seluruh peserta. Kapasitas dan harga sewa setiap jenis tenda ditunjukkan pada tabel berikut:",
    table: { headers: ["Tenda", "Kapasitas", "Harga Sewa"], rows: [["Kecil", "6 orang", "Rp240.000"], ["Sedang", "10 orang", "Rp350.000"], ["Besar", "15 orang", "Rp555.000"]] },
    statements: [
      "1. Peserta perkemahan berjumlah 150 orang.",
      "2. Semua peserta harus mendapat tempat.",
      "3. Tenda yang disewa harus terisi penuh (tidak boleh ada tempat kosong).",
      "4. Panitia ingin biaya sewa paling hemat."
    ],
    after: "Berdasarkan informasi tersebut, kombinasi tenda yang paling hemat adalah ...",
    options: ["10 tenda Besar", "15 tenda Sedang", "25 tenda Kecil", "6 tenda Besar dan 6 tenda Sedang", "12 tenda Sedang dan 2 tenda Kecil"],
    answer: "B",
    explanation: [
      "Syarat kunci: jumlah tempat harus TEPAT 150 orang.",
      "Cek setiap opsi:",
      "A. 10 Besar → 10 × 15 = 150 orang, biaya 10 × 555.000 = Rp5.550.000.",
      "B. 15 Sedang → 15 × 10 = 150 orang, biaya 15 × 350.000 = Rp5.250.000.",
      "C. 25 Kecil → 25 × 6 = 150 orang, biaya 25 × 240.000 = Rp6.000.000.",
      "D. 6 Besar + 6 Sedang → 90 + 60 = 150 orang, biaya 3.330.000 + 2.100.000 = Rp5.430.000.",
      "E. 12 Sedang + 2 Kecil → 120 + 12 = 132 orang (kurang dari 150, tidak memenuhi syarat), biaya Rp4.680.000.",
      "Jawaban: B"
    ]
  },
  {
    prompt: "Sebuah perusahaan akan menyewa kendaraan untuk mengantar karyawan ke lokasi gathering. Kapasitas dan harga sewa setiap jenis kendaraan ditunjukkan pada tabel berikut:",
    table: { headers: ["Kendaraan", "Kapasitas", "Harga Sewa"], rows: [["City car", "4 orang", "Rp450.000"], ["MPV", "7 orang", "Rp700.000"], ["Minibus", "12 orang", "Rp1.080.000"]] },
    statements: [
      "1. Karyawan yang ikut berjumlah 47 orang.",
      "2. Semua karyawan harus mendapat tempat duduk (boleh ada kursi kosong).",
      "3. Setiap jenis kendaraan hanya boleh disewa maksimal 3 unit.",
      "4. Perusahaan ingin biaya sewa paling hemat."
    ],
    after: "Berdasarkan informasi tersebut, kombinasi kendaraan yang paling hemat adalah ...",
    options: ["4 Minibus", "3 Minibus dan 3 City car", "3 Minibus dan 1 MPV", "2 Minibus, 3 MPV, dan 1 City car", "3 Minibus, 1 MPV, dan 1 City car"],
    answer: "E",
    explanation: [
      "Syarat kunci: kursi MINIMAL 47 (boleh lebih) dan tiap jenis MAKSIMAL 3 unit.",
      "Cek setiap opsi:",
      "A. 4 Minibus → 48 kursi, biaya Rp4.320.000 (Minibus disewa 4 unit, melanggar batas maksimal 3).",
      "B. 3 Minibus + 3 City car → 36 + 12 = 48 kursi, biaya 3.240.000 + 1.350.000 = Rp4.590.000.",
      "C. 3 Minibus + 1 MPV → 36 + 7 = 43 kursi (kurang dari 47, tidak memenuhi syarat), biaya Rp3.940.000.",
      "D. 2 Minibus + 3 MPV + 1 City car → 24 + 21 + 4 = 49 kursi, biaya 2.160.000 + 2.100.000 + 450.000 = Rp4.710.000.",
      "E. 3 Minibus + 1 MPV + 1 City car → 36 + 7 + 4 = 47 kursi, biaya 3.240.000 + 700.000 + 450.000 = Rp4.390.000.",
      "Kesimpulan: opsi E paling hemat dengan biaya Rp4.390.000 dan kapasitas tepat 47 orang.",
      "Jawaban: E"
    ]
  },
  {
    prompt: "Gambar selanjutnya yang paling tepat adalah ...",
    visual: "q28.webp",
    options: ["A", "B", "C", "D", "E"],
    answer: "A",
    explanation: [
      "Pola gambar dilihat dari kiri ke kanan dengan ketentuan berikut:",
      "Siluet yang sama berputar 45° BERLAWANAN arah jarum jam di setiap gambar.",
      "Gambar ke-5 adalah gambar ke-4 yang diputar 45° lagi berlawanan arah jarum jam (total 180° dari gambar pertama).",
      "Sehingga gambar paling tepat adalah opsi A."
    ]
  },
  {
    prompt: "Gambar selanjutnya yang paling tepat adalah ...",
    visual: "q29.webp",
    options: ["A", "B", "C", "D", "E"],
    answer: "C",
    explanation: [
      "Pola gambar dilihat dari kiri ke kanan. Ada 3 komponen dengan pola masing-masing:",
      "Siluet: berputar 60° searah jarum jam di setiap gambar.",
      "Jumlah tetesan: berulang 1, 2, 3, 1, 2.",
      "Warna siluet: berganti setiap DUA gambar (putih, putih, abu-abu, abu-abu, putih).",
      "Sehingga gambar paling tepat adalah opsi C."
    ]
  },
  {
    prompt: "Manakah gambar yang berbeda dari yang lain?",
    visual: "q30.webp",
    options: ["A", "B", "C", "D", "E"],
    answer: "D",
    explanation: [
      "Semua gambar memakai siluet sama dan diputar dengan sudut berbeda. Namun satu gambar bukan hanya diputar, tetapi juga DICERMINKAN yaitu opsi D."
    ]
  },
  {
    prompt: "Manakah gambar yang berbeda dari yang lain?",
    visual: "q31.webp",
    options: ["A", "B", "C", "D", "E"],
    answer: "A",
    explanation: [
      "Setiap gambar berisi siluet dan sebuah panah di dalamnya.",
      "Pada opsi B, C, D, dan E, panah selalu menunjuk ke arah TONJOLAN TERPANJANG siluet.",
      "Pada opsi A, panah menunjuk ke arah lain (bukan ke tonjolan terpanjang).",
      "Sehingga gambar yang berbeda adalah opsi A."
    ]
  },
  {
    prompt: "Manakah gambar yang berbeda dari yang lain?",
    visual: "q32.webp",
    options: ["A", "B", "C", "D", "E"],
    answer: "B",
    explanation: [
      "Setiap gambar berisi satu siluet, beberapa garis bergelombang, serta bulatan hitam dan putih.",
      "Aturannya: jumlah garis yang MEMOTONG (melewati) garis tepi siluet = jumlah bulatan HITAM.",
      "A: garis memotong siluet 2, bulatan hitam 2 → sama.",
      "B: garis memotong siluet 3, bulatan hitam 2 → TIDAK sama.",
      "C: garis memotong siluet 1, bulatan hitam 1 → sama.",
      "D: garis memotong siluet 3, bulatan hitam 3 → sama.",
      "E: garis memotong siluet 2, bulatan hitam 2 → sama.",
      "Sehingga gambar yang berbeda adalah opsi B."
    ]
  },
  {
    prompt: "Gambar yang tepat untuk mengisi tanda tanya adalah ...",
    visual: "q33.webp",
    options: ["A", "B", "C", "D", "E"],
    answer: "C",
    explanation: [
      "Pola gambar dilihat secara horizontal dan vertikal dengan ketentuan berikut:",
      "Setiap baris dan setiap kolom memuat 3 bentuk siluet yang berbeda (masing-masing muncul 1 kali).",
      "Setiap baris dan setiap kolom memuat 3 jenis arsiran berbeda: putih, abu-abu, dan garis miring (masing-masing muncul 1 kali).",
      "Sehingga gambar paling tepat adalah opsi C."
    ]
  },
  {
    prompt: "Gambar yang tepat untuk mengisi tanda tanya adalah ...",
    visual: "q34.webp",
    options: ["A", "B", "C", "D", "E"],
    answer: "E",
    explanation: [
      "Pola gambar dilihat secara horizontal dengan ketentuan berikut:",
      "Siluet sama dalam satu baris (bentuk dan posisi tidak berubah).",
      "Jumlah tetesan kolom 3 = jumlah tetesan kolom 1 + kolom 2.",
      "Warna tetesan mengikuti kolom: kolom 1 putih, kolom 2 abu-abu, kolom 3 hitam.",
      "Sehingga gambar paling tepat adalah opsi E."
    ]
  },
  {
    prompt: "Gambar yang tepat untuk mengisi tanda tanya adalah ...",
    visual: "q35.webp",
    options: ["A", "B", "C", "D", "E"],
    answer: "E",
    explanation: [
      "Pola gambar dilihat secara horizontal dengan ketentuan:",
      "Bentuk abstrak di tengah: diputar 90° searah jarum jam.",
      "Garis bergelombang: jumlah kolom 3 = kolom 1 + kolom 2.",
      "Bulatan hitam: berkurang 1 di setiap kolom.",
      "Bulatan putih: bertambah 1 di setiap kolom.",
      "Sehingga gambar paling tepat adalah opsi E."
    ]
  }
];
